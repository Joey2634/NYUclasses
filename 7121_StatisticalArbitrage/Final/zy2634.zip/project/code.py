#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
from datetime import datetime
from math import sqrt

import ta
import yfinance as yf
from prophet import Prophet

import statsmodels
from statsmodels.tsa.stattools import coint
import statsmodels.api as sm
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.vector_ar.var_model import VAR
from pykalman import KalmanFilter

from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_squared_error
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from keras.layers import Dropout

from matplotlib import pyplot
import plotly.offline as py
import plotly.graph_objs as go
import seaborn as sns

import warnings
warnings.filterwarnings("ignore")


# # Fetch data from yahoo

# In[2]:


startDateStr = '2015-01-01'
endDateStr = '2023-03-20'

etfid = ['SPY', 'IVV', 'VTI', 'VOO', 'QQQ',
        'VEA', 'VTV', 'IEFA', 'BND', 'AGG',
        'VUG', 'IJR', 'VWO', 'IJH', 'IEMG',
        'VIG', 'IWF', 'IWM', 'GLD', 'VXUS', 
        'VO', 'IWD', 'VYM', 'EFA', 'BNDX']
data = yf.download(tickers=etfid, start=startDateStr, end=endDateStr)

data_close = data['Adj Close']
data_open = data['Open']
data_high = data['High']
data_low = data['Low']
data_vol = data['Volume']


# # Data virtualization

# In[3]:


print(data_close.shape)
data_close.head()


# In[4]:


data_close.plot(figsize = (15, 7))


# # Find Co-Integrated Pairs

# In[5]:


def cointegrated_pairs(dataframe, threshold=0.05):
    num_stocks = dataframe.shape[1]
    score_matrix = np.zeros((num_stocks, num_stocks))
    pvalue_matrix = np.ones((num_stocks, num_stocks))
    stocks = dataframe.columns
    pairs = {}
    for i in range(num_stocks):
        for j in range(i+1, num_stocks):
            S1 = dataframe[stocks[i]]
            S2 = dataframe[stocks[j]]
            result = coint(S1, S2)
            score = result[0]
            pvalue = result[1]
            score_matrix[i, j] = score
            pvalue_matrix[i, j] = pvalue
            if pvalue < threshold:
                pairs[(stocks[i], stocks[j])] = result
    return pvalue_matrix, pairs


# In[6]:


pvalues, pairs = cointegrated_pairs(data_close)
sns.heatmap(pvalues)
pyplot.show()


# In[7]:


pair_list = [(key[0], key[1], round(value[0], 2), round(value[1], 5)) for key, value in pairs.items()]
pair_list = sorted(pair_list, key=lambda x: x[2], reverse=False)
top_pairs = pair_list[:10]
top_pairs_df = pd.DataFrame(top_pairs, columns=['ETF_1', 'ETF_2', 'Score', 'P-Value'])
top_pairs_df


# In[8]:


pair_data = pd.DataFrame({'S1_close':data_close['IWM'],'S2_close':data_close['VEA']
                         ,'S1_open':data_open['IWM'],'S2_open':data_open['VEA']
                         ,'S1_high':data_high['IWM'],'S2_high':data_high['VEA']
                         ,'S1_low':data_low['IWM'],'S2_low':data_low['VEA']
                         ,'S1_volume':data_vol['IWM'],'S2_volume':data_vol['VEA']})


# ## Adding Technical Indictors

# ## Momentum Indicators

# In[9]:


# Relative Strength Index
pair_data['S1_rsi'] = ta.momentum.rsi(pair_data['S1_close'], window=7)
pair_data['S2_rsi'] = ta.momentum.rsi(pair_data['S2_close'], window=7)
# Money Flow Index
pair_data['S1_mfi'] = ta.volume.money_flow_index(pair_data['S1_high'], pair_data['S1_low'], 
                                                   pair_data['S1_close'], pair_data['S1_volume'], window=7)
pair_data['S2_mfi'] = ta.volume.money_flow_index(pair_data['S2_high'], pair_data['S2_low'], 
                                                   pair_data['S2_close'], pair_data['S2_volume'], window=7)


# ## Volume Indicators

# In[10]:


# Accumulation/Distribution Index (ADI)
pair_data['S1_adi'] = ta.volume.acc_dist_index(pair_data['S1_high'], pair_data['S1_low'], pair_data['S1_close'], pair_data['S1_volume'])
pair_data['S2_adi'] = ta.volume.acc_dist_index(pair_data['S2_high'], pair_data['S2_low'], pair_data['S2_close'], pair_data['S2_volume'])
# Volume-price trend (VPT)
pair_data['S1_vpt'] = ta.volume.volume_price_trend(pair_data['S1_close'], pair_data['S1_volume'])
pair_data['S2_vpt'] = ta.volume.volume_price_trend(pair_data['S2_close'], pair_data['S2_volume'])


# ## Volatility Indicators

# In[11]:


# Average True Range (ATR)
pair_data['S1_atr'] = ta.volatility.average_true_range(pair_data['S1_high'], pair_data['S1_low'], 
                                                       pair_data['S1_close'], window=7)
pair_data['S2_atr'] = ta.volatility.average_true_range(pair_data['S2_high'], pair_data['S2_low'], 
                                                       pair_data['S2_close'], window=7)

# Bollinger Bands (BB) N-period simple moving average (MA)
pair_data['S1_bb_ma'] = ta.volatility.bollinger_mavg(pair_data['S1_close'], window=7)
pair_data['S2_bb_ma'] = ta.volatility.bollinger_mavg(pair_data['S2_close'], window=7)


# ## Trend Indicators

# In[12]:


# Average Directional Movement Index (ADX)
pair_data['S1_adx'] = ta.trend.adx(pair_data['S1_high'], pair_data['S1_low'], pair_data['S1_close'], window=7)
pair_data['S2_adx'] = ta.trend.adx(pair_data['S2_high'], pair_data['S2_low'], pair_data['S2_close'], window=7)
# Exponential Moving Average
pair_data['S1_ema'] = ta.trend.ema_indicator(pair_data['S1_close'], window=7)
pair_data['S2_ema'] = ta.trend.ema_indicator(pair_data['S2_close'], window=7)
# Moving Average Convergence Divergence (MACD)
pair_data['S1_macd'] = ta.trend.macd(pair_data['S1_close'], window_fast=7, window_slow=14)
pair_data['S2_macd'] = ta.trend.macd(pair_data['S2_close'], window_fast=7, window_slow=14)


# ## Spreads for reference

# In[13]:


est = sm.OLS(pair_data.S1_close, pair_data.S2_close).fit()
pair_data['Spread_Close'] = pair_data.S1_close - est.params[0]*pair_data.S2_close

est_op = sm.OLS(pair_data.S1_open, pair_data.S2_open).fit()
pair_data['Spread_Open'] = pair_data.S1_open - est_op.params[0]*pair_data.S2_open

est_hi = sm.OLS(pair_data.S1_high, pair_data.S2_high).fit()
pair_data['Spread_High'] = pair_data.S1_high - est_hi.params[0]*pair_data.S2_high

est_lo = sm.OLS(pair_data.S1_low, pair_data.S2_low).fit()
pair_data['Spread_Low'] = pair_data.S1_low -est_lo.params[0]*pair_data.S2_low


pair_data['Spread_Close'].plot(figsize=(15,7))
pyplot.legend(['Spread_Close'])


# ## Dataset split

# In[14]:


pair_data = pair_data.iloc[14:,]


# In[15]:


cols = ['Spread_Close', 'Spread_Open', 'Spread_High', 'Spread_Low', 'S1_volume',
        'S2_volume', 'S1_rsi', 'S2_rsi', 'S1_mfi', 'S2_mfi', 'S1_adi', 'S2_adi',
        'S1_vpt', 'S2_vpt', 'S1_atr', 'S2_atr', 'S1_bb_ma', 'S2_bb_ma', 'S1_adx',
        'S2_adx', 'S1_ema', 'S2_ema', 'S1_macd', 'S2_macd']


# In[16]:


lstm_data = pair_data.loc[:,cols]


# In[17]:


train_size = int(len(lstm_data) * 0.9)
dev_size = int((len(lstm_data) - train_size) * 0.5) - 30
test_size = len(lstm_data) - train_size - dev_size
train, dev, test = lstm_data[0:train_size], lstm_data[train_size:train_size + dev_size], lstm_data[train_size + dev_size:len(lstm_data)]
print(len(train), len(dev), len(test))


# ## Prediction Period Setting

# In[18]:


scaler = MinMaxScaler(feature_range=(0, 1))
def create_dataset(dataset, look_back=1):
    dataX, dataY = [], []
    for i in range(len(dataset) - look_back):
        a = dataset[i, :]
        dataX.append(a)
        dataY.append(dataset[(i+1):(i+1+look_back), 0])
    print(len(dataY))
    return dataX, np.array(scaler.fit_transform(dataX)), dataY, np.array(scaler.fit_transform(dataY))


# In[19]:


trainX_untr, trainX, trainY_untr, trainY = create_dataset(train.values, 1)
devX_untr, devX, devY_untr, devY = create_dataset(dev.values, 1)
testX_untr, testX, testY_untr, testY = create_dataset(test.values, 1)


# ## ACCURACY METRIC

# In[20]:


def acc_metric(true_value, predicted_value):
    acc_met = 0.0
    m = len(true_value)
    for i in range(m):
        acc_met += mean_squared_error(true_value[i], predicted_value[i])
    acc_met /= m
    return np.sqrt(acc_met)


# ## Use Kalman Filter to Predict

# In[21]:


def KalmanFilterAverage(x):
  # Construct a Kalman filter
    kf = KalmanFilter(transition_matrices = [1],
    observation_matrices = [1],
    initial_state_mean = 0,
    initial_state_covariance = 1,
    observation_covariance=1,
    transition_covariance=.01)
 
  # Use the observed values of the price to get a rolling mean
    state_means, _ = kf.filter(x.values)
    state_means = pd.Series(state_means.flatten(), index=x.index)
    return state_means
 
# Kalman filter regression
def KalmanFilterRegression(x,y):
    delta = 1e-3
    trans_cov = delta / (1 - delta) * np.eye(2) # How much random walk wiggles
    obs_mat = np.expand_dims(np.vstack([[x], [np.ones(len(x))]]).T, axis=1)
 
    kf = KalmanFilter(n_dim_obs=1, n_dim_state=2, # y is 1-dimensional, (alpha, beta) is 2-dimensional
    initial_state_mean=[0,0],
    initial_state_covariance=np.ones((2, 2)),
    transition_matrices=np.eye(2),
    observation_matrices=obs_mat,
    observation_covariance=2,
    transition_covariance=trans_cov)
 
    # Use the observations y to get running estimates and errors for the state parameters
    state_means, state_covs = kf.filter(y.values)
    return state_means


# In[22]:


def normalize(series):
    return (series - np.mean(series)) / np.std(series)


# In[23]:


state_means = - KalmanFilterRegression(KalmanFilterAverage(pair_data.S1_close),KalmanFilterAverage(pair_data.S2_close))[:,0]
results = normalize(pair_data.S1_close + (pair_data.S2_close * state_means))
forecast = results[-len(testX):].values
yhat_KF = forecast
yhat_KF_mse = []
mse = 0.0
for i in range(len(forecast)):
    temp = []
    temp.append(forecast[i])
    yhat_KF_mse.append(np.array(temp))
mse = acc_metric(normalize(testY_untr), yhat_KF_mse)
mse


# In[54]:


normalize(pair_data['Spread_Close']).plot(figsize=(15,7))
results.plot(figsize=(15,7))
pyplot.legend(['Spread', 'Kalman_Predicted_Spread'])
pyplot.show()


# ## Spread Prediction using ARIMA

# In[25]:


yhat_ARIMA = []
yhat_ARIMA_mse = []
data = lstm_data['Spread_Close'].values
for i in range(train_size+dev_size, len(lstm_data)-1):
    model = ARIMA(data[:i], order=(1,0,0))
    model_fit = model.fit()
    temp = []
    forecast = (model_fit.forecast(steps=1))
    yhat_ARIMA.append(forecast[0])
    for j in range(len(forecast)):
        temp.append(forecast[j])
    yhat_ARIMA_mse.append(np.array(temp))
mse = 0.0
mse = acc_metric(testY_untr, yhat_ARIMA_mse)
mse


# ## Spread Prediction using LSTM

# In[28]:


# Reshape X for model training
trainX = trainX.reshape((trainX.shape[0], 1, trainX.shape[1]))
devX = np.reshape(devX, (devX.shape[0], 1, devX.shape[1]))
testX = np.reshape(testX, (testX.shape[0], 1, testX.shape[1]))
# Running the LSTM model
model = Sequential()
model.add(LSTM(256, input_shape=(trainX.shape[1], trainX.shape[2]), return_sequences = True))
model.add(LSTM(256))
model.add(Dropout(0.2))
model.add(Dense(1))
model.compile(loss='mse', optimizer='adam', metrics=['accuracy'])
history = model.fit(trainX, trainY, epochs=200, batch_size=20, validation_data=(devX, devY), verbose=0, shuffle=True)


# In[29]:


model.summary()


# In[30]:


# Plot line graph to show amount loss according the the epoch
pyplot.plot(history.history['loss'], label='train')
pyplot.plot(history.history['val_loss'], label='dev')
pyplot.legend()
pyplot.show()


# In[31]:


# Make prediction using textX and plotting line graph against testY
yhat = model.predict(testX)
pyplot.plot(testY, label='True Value')
pyplot.plot(yhat, label='Predicted Value')
pyplot.legend()
pyplot.show()


# In[32]:


# Scaler Inverse Y back to normal value

yhat_LSTM = scaler.inverse_transform(yhat)
testY_LSTM = scaler.inverse_transform(testY)


# In[33]:


# Training and Test error
mse_train = acc_metric(scaler.inverse_transform(trainY), scaler.inverse_transform(model.predict(trainX)))
mse_test = acc_metric(yhat_LSTM, testY_LSTM)
mse_train, mse_test


# In[35]:


predictDates = lstm_data.tail(len(testX)).index
testY_reshape = normalize(testY_LSTM).reshape(len(testY_LSTM))
yhat_reshape = normalize(yhat_LSTM).reshape(len(yhat_LSTM))
kalman_reshape = normalize(yhat_KF).reshape(len(yhat_KF))
#Plot predicted and actual line graph
layout = go.Layout(yaxis=dict(title='Spread',titlefont=dict(family='Arial, sans-serif',size=18)))
actual_chart = go.Scatter(x=predictDates, y=testY_reshape, name= 'Actual Spread')
predict_chart = go.Scatter(x=predictDates, y=yhat_reshape, name= 'LSTM Predict Spread')
predict_kalman_chart = go.Scatter(x=predictDates, y=kalman_reshape, name= 'Kalman Filter Predict Spread')
fig = go.Figure(data = [predict_kalman_chart, predict_chart, actual_chart], layout = layout)
py.iplot(fig)


# ## Trading Strategy

# In[46]:


# Test Data
test_data = pd.DataFrame({'S1':pair_data['S1_close'].iloc[-len(testX):],'S2':pair_data['S2_close'].iloc[-len(testX):]})
test_data['Actual_Spread'] = pair_data['Spread_Close'].iloc[-len(testX):]
test_data['Kalman_Predicted_Spread']  = yhat_KF
test_data['ARIMA_Predicted_Spread']  = yhat_ARIMA
test_data['LSTM_Predicted_Spread'] = list(yhat_LSTM[:,0])
data = test_data['LSTM_Predicted_Spread']


# In[47]:


ratios_mavg5 = data.rolling(window=5,center=False).mean()
ratios_mavg60 = data.rolling(window=60,center=False).mean()
std_60 = data.rolling(window=60,center=False).std()
zscore_60_5 = (ratios_mavg5 - ratios_mavg60)/std_60

pyplot.figure(figsize=(15,7))
pyplot.plot(data.index, data.values)
pyplot.plot(ratios_mavg5.index, ratios_mavg5.values)
pyplot.plot(ratios_mavg60.index, ratios_mavg60.values)
pyplot.legend(['Spread','5d Ratio MA', '60d Ratio MA'])

pyplot.ylabel('Spread')
pyplot.show()


# In[67]:


# Take a rolling 60 day standard deviation
std_60 = data.rolling(window=60,center=False).std()
std_60.name = 'std 60d'

# Compute the z score for each day
zscore_60_5 = (ratios_mavg5 - ratios_mavg60)/std_60
zscore_60_5.name = 'z-score'

pyplot.figure(figsize=(15,7))
zscore_60_5.plot()
pyplot.axhline(0, color='black')
pyplot.axhline(0.5, color='red', linestyle='--')
pyplot.axhline(-0.5, color='green', linestyle='--')
pyplot.legend(['Rolling Spread z-Score', 'Mean', '+1', '-1'])
pyplot.show()


# In[84]:


buy = data.copy()
sell = data.copy()
buy[zscore_60_5>-0.5] = -100
sell[zscore_60_5<0.5] = -100


# In[69]:


# Plot the prices and buy and sell signals from z score
pyplot.figure(figsize=(18,9))
S1 = test_data.S1
S2 = test_data.S2

S1[60:].plot(color='b')
S2[60:].plot(color='c')
buyR = 0*S1.copy()
sellR = 0*S1.copy()

# When buying the ratio, buy S1 and sell S2
buyR[buy!=-100] = S1[buy!=-100]
sellR[buy!=-100] = S2[buy!=-100]
# When selling the ratio, sell S1 and buy S2 
buyR[sell!=-100] = S2[sell!=-100]
sellR[sell!=-100] = S1[sell!=-100]

buyR[60:].plot(color='g', linestyle='None', marker='^')
sellR[60:].plot(color='r', linestyle='None', marker='^')
x1,x2,y1,y2 = pyplot.axis()
pyplot.axis((x1,x2,min(S1.min(),S2.min()),max(S1.max(),S2.max())))

pyplot.legend(['S1', 'S2', 'Buy Signal', 'Sell Signal'])
pyplot.show()


# In[80]:


def trade(S1, S2, spread, window1, window2):
    # If window length is 0, algorithm doesn't make sense, so exit
    if (window1 == 0) or (window2 == 0):
        return 0
    # Compute rolling mean and rolling standard deviation
    ma1 = spread.rolling(window=window1, center=False).mean()
    ma2 = spread.rolling(window=window2, center=False).mean()
    std = spread.rolling(window=window2, center=False).std()
    zscore = (ma1 - ma2)/std
    # Simulate trading
    # Start with no money and no positions
    cash = []
    money = 0
    countS1 = 0
    countS2 = 0
    for i in range(len(spread)):
        # Sell short if the z-score is > 0.5
        if zscore[i] > 0.5:
            money += S1[i] - S2[i] * 4
            countS1 -= 1
            countS2 += spread[i]
        # Buy long if the z-score is < 0.5
        elif zscore[i] < -0.5:
            money -= S1[i] - S2[i] * 4
            countS1 += 1
            countS2 -= spread[i]
        # Clear positions if the z-score between -.5 and .5
        elif abs(zscore[i]) < 0.2:
            money += countS1 * S1[i] - S2[i] * countS2
            countS1 = 0
            countS2 = 0
        cash.append(money)
    return money, cash


# In[86]:


data = test_data['ARIMA_Predicted_Spread']
profit, cash = trade(test_data['S1'], test_data['S2'], data, 30, 5)
profit


# In[ ]:




